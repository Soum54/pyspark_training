import scala.io.Source
import scala.util.{Try, Success, Failure}

// --------------------------------
// Trait
// --------------------------------
trait Printable {
  def printInfo(): Unit
}

// --------------------------------
// Parent class
// --------------------------------
class Person(
    val name: String
) {
  def role: String = "Person"
}

// --------------------------------
// Inheritance + polymorphism
// --------------------------------
class Employee(
    name: String,
    val department: String
) extends Person(name) {

  override def role: String = "Employee"
}

// --------------------------------
// Case class
// --------------------------------
case class Sale(
    orderId: Int,
    customer: String,
    category: String,
    quantity: Int,
    price: Double
) extends Printable {

  def revenue: Double =
    quantity * price

  override def printInfo(): Unit = {
    println(
      s"$orderId | $customer | $category | $quantity | $price"
    )
  }
}

// --------------------------------
// Generic class
// --------------------------------
class DataBox[T](val value: T) {

  def display(): Unit =
    println(value)
}

// --------------------------------
// Type class
// --------------------------------
trait Formatter[T] {
  def format(value: T): String
}

object Formatter {

  implicit val saleFormatter: Formatter[Sale] =
    new Formatter[Sale] {

      override def format(s: Sale): String =
        s"Order=s.orderId,Customer={s.customer}, Revenue=${s.revenue}"
    }
}

// --------------------------------
// Main singleton object
// --------------------------------
object RetailScalaLab {

  // Higher-order function
  def transformValues(
      values: List[Int],
      operation: Int => Int
  ): List[Int] = {

    values.map(operation)
  }

  // Pure function
  def calculateRevenue(
      quantity: Int,
      price: Double
  ): Double = {

    quantity * price
  }

  // Generic function using type class
  def printFormatted[T](
      value: T
  )(implicit formatter: Formatter[T]): Unit = {

    println(formatter.format(value))
  }

  // Option
  def findSale(
      sales: List[Sale],
      id: Int
  ): Option[Sale] = {

    sales.find(_.orderId == id)
  }

  // Either
  def validateQuantity(
      quantity: Int
  ): Either[String, Int] = {

    if (quantity > 0)
      Right(quantity)
    else
      Left("Quantity must be greater than zero")
  }

  // Pattern matching
  def classifyRevenue(
      revenue: Double
  ): String = revenue match {

    case r if r >= 70000 =>
      "HIGH VALUE"

    case r if r >= 30000 =>
      "MEDIUM VALUE"

    case _ =>
      "LOW VALUE"
  }

  def main(args: Array[String]): Unit = {

    println("\n===== SCALA RETAIL TRAINING LAB =====")

    // ==================================================
    // 1. Tuple
    // ==================================================

    println("\n--- Tuple ---")

    val customer =
      (101, "Anu", "Chennai")

    println(customer)

    println(customer._1)
    println(customer._2)
    println(customer._3)

    // ==================================================
    // 2. Array
    // ==================================================

    println("\n--- Array ---")

    val quantities =
      Array(1, 2, 3, 4, 5)

    quantities.foreach(println)

    // Arrays are mutable

    quantities(0) = 10

    println(
      quantities.mkString(",")
    )

    // ==================================================
    // 3. List
    // ==================================================

    println("\n--- List ---")

    val categories =
      List(
        "Laptop",
        "Mobile",
        "Tablet",
        "Accessories"
      )

    categories.foreach(println)

    // ==================================================
    // 4. Map transformation
    // ==================================================

    println("\n--- map ---")

    val prices =
      List(
        1000,
        2000,
        3000
      )

    val increasedPrices =
      prices.map(_ * 1.10)

    println(increasedPrices)

    // ==================================================
    // 5. Filter
    // ==================================================

    println("\n--- filter ---")

    val expensive =
      increasedPrices.filter(_ > 2000)

    println(expensive)

    // ==================================================
    // 6. flatMap
    // ==================================================

    println("\n--- flatMap ---")

    val products =
      List(
        "Laptop Bag",
        "Mobile Phone",
        "USB Cable"
      )

    val words =
      products.flatMap(
        _.split(" ")
      )

    println(words)

    // ==================================================
    // 7. Pattern matching
    // ==================================================

    println("\n--- Pattern Matching ---")

    println(
      classifyRevenue(85000)
    )

    // ==================================================
    // 8. Higher-order function
    // ==================================================

    println("\n--- Higher Order Function ---")

    val numbers =
      List(1, 2, 3, 4)

    val doubled =
      transformValues(
        numbers,
        x => x * 2
      )

    println(doubled)

    // ==================================================
    // 9. Pure function
    // ==================================================

    println("\n--- Pure Function ---")

    println(
      calculateRevenue(
        3,
        20000
      )
    )

    // ==================================================
    // 10. OOP
    // ==================================================

    println("\n--- OOP ---")

    val employee =
      new Employee(
        "Anand",
        "Data Engineering"
      )

    println(employee.name)
    println(employee.department)
    println(employee.role)

    // ==================================================
    // 11. Case class
    // ==================================================

    println("\n--- Case Class ---")

    val sampleSale =
      Sale(
        1001,
        "Anu",
        "Laptop",
        1,
        65000
      )

    println(sampleSale)

    sampleSale.printInfo()

    // ==================================================
    // 12. Generic class
    // ==================================================

    println("\n--- Generics ---")

    val intBox =
      new DataBox[Int](100)

    val stringBox =
      new DataBox[String]("Scala")

    intBox.display()
    stringBox.display()

    // ==================================================
    // 13. Type class
    // ==================================================

    println("\n--- Type Class ---")

    import Formatter._

    printFormatted(sampleSale)

    // ==================================================
    // 14. Try
    // ==================================================

    println("\n--- Try ---")

    val result =
      Try("100".toInt)

    result match {

      case Success(value) =>
        println(
          s"Converted value = $value"
        )

      case Failure(ex) =>
        println(
          s"Error = ${ex.getMessage}"
        )
    }

    // ==================================================
    // 15. Option
    // ==================================================

    println("\n--- Option ---")

    val sales =
      List(
        Sale(1001, "Anu", "Laptop", 1, 65000),
        Sale(1002, "Ravi", "Mobile", 2, 25000)
      )

    val searchResult =
      findSale(
        sales,
        1001
      )

    println(searchResult)

    // ==================================================
    // 16. Either
    // ==================================================

    println("\n--- Either ---")

    println(
      validateQuantity(5)
    )

    println(
      validateQuantity(-5)
    )

    // ==================================================
    // 17. Immutability
    // ==================================================

    println("\n--- Immutability ---")

    val original =
      List(10, 20, 30)

    val updated =
      original :+ 40

    println(original)

    println(updated)

    println("\n===== LAB COMPLETED =====")
  }
}



    
    

















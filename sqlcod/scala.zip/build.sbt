ThisBuild / scalaVersion := "2.12.18"

name := "scala-retail-lab"

version := "1.0"

Compile / mainClass := Some("RetailScalaLab")

assembly / mainClass := Some("RetailScalaLab")

assembly / assemblyJarName := "scala-retail-lab.jar"
